# Optymalizacja TROJNIK_TEST — YASKAWA DX200

Analiza archiwum `TOFIK_270826.rar`, przygotowana 14.10.2026. Uwzględniono 97 plików JBI przy identyfikacji zależności i wszystkie 21 programów osiągalnych z `TROJNIK_TEST`: program główny oraz 20 podprogramów. Wszystkie wywoływane programy są w archiwum.

**Rezultat: komplet JBI do przeglądu i prób offline, a nie wersja zatwierdzona do produkcji.** Zachowano sekcje pozycji, narzędzia, układy, polecenia ruchu, wartości prędkości, PL, timery, oczekiwania i wyjścia. Zamierzonymi zmianami zachowania są odczyt trybów/korekt na początku sztuki i wstrzymanie startu przy recepturze innej niż `I035=30`. Kompensacja zużycia pozostała zgodna z potwierdzeniem użytkownika.

## Co zmieniono

| Program | Zmiana |
|---|---|
| `TROJNIK_TEST` | Dodano opisy etapów; odczyt `OT#(33)` do `B015`; dla szlifu całego odczyt `OT#(26)` do `B012`; przeliczenie odpowiednich korekt `I100–I108` do `D100–D108` raz na sztukę; kontrola receptury. |
| `MONTAZ_TROJNIKA`, `OBLICZENIA_KROKOW_TROJNIKI`, `WYBOR_SZLIFU` | Usunięto ponowny odczyt `OT#(33)`. Korzystają z `B015` ustalonego przez program główny. |
| `SZLIF_TROJNIKA` | Korzysta z `B012` ustalonego przez program główny. Pozostawiono wszystkie wywołania obliczeń, także powtórzone w trybie 8 przejść. |
| `OBLICZ_SZLIF_CALY_TROJ_1/2/3` | Usunięto po 66 przypisań, które powtarzały tę samą wartość przy niezmienionych argumentach. Zachowano każde `SETE`, kolejność zapisu punktów oraz skutki kompensacji zużycia. Korekty są już przeliczone przez program główny. |
| `OBLICZ_SZLIF_TROJNIKA` | Usunięto 3 powtarzające się przypisania wysokości; korekty pochodzą z programu głównego. |
| Pozostałe programy | Komentarze tam, gdzie pomagają zrozumieć zależności; instrukcje wykonawcze pozostały bez zmian. |

W czterech programach obliczeniowych usunięto łącznie **201 powtórnych przypisań** w tekście kodu. Nie usuwano całych wywołań obliczeń. Nie dodano nowych zmiennych globalnych ani podprogramów.

Przykład pierwszej strony: po obliczeniu `D069=900000`, `D070=0`, `D071=900000` kolejne punkty używają tych samych wartości. Nie trzeba ich ponownie przypisywać przed każdym `SETE`. Analogicznie nie trzeba ponownie obliczać identycznego `D068`, jeśli jego argumenty nie zostały zmienione.

### Ustawienia na kolejną sztukę

Wersja robocza odczytuje tryb i korekty po etykiecie `*LOOP`, **przed oczekiwaniem na detal na taśmie**. Zmiany dokonane później obowiązują od kolejnego przejścia przez `*LOOP`. Dla spawu kopiuje `I103–I105`, a dla całego trójnika `I100–I108`. `B012` jest odczytywane tylko w trybie całego trójnika.

Podprogramy obróbki mają teraz jawny warunek wejściowy: `B015`, `B012` oraz odpowiednie `D100–D108` muszą pochodzić z początku cyklu `TROJNIK_TEST`. Samodzielne wywołanie zmienionego podprogramu z pendantu wymaga przygotowania tych wartości. **Nie należy mieszać zmienionych i oryginalnych plików tej sekwencji.**

Kopia dotyczy wymienionych trybów i korekt. `I035`, `I070`, `I072`, `I076` oraz inne parametry nadal są zmiennymi wspólnymi; PLC/HMI powinno utrzymywać je podczas cyklu. Odczyty kilku zmiennych nie są transakcją atomową: konfigurację trzeba zatwierdzić przed początkiem sztuki. Jeżeli PLC ma aktualizować całą recepturę podczas pracy, potrzebny będzie oddzielny bufor parametrów i sygnał zatwierdzenia po sprawdzeniu mapy komunikacji.

`B015`, `B012`, `D100–D108` i `P000–P033` są roboczym stanem cyklu. Inny równoległy job, PLC ani HMI nie powinny ich nadpisywać. W archiwum istnieje również `OBLICZ_SZLIF_CALY_TROJ`, który zapisuje korekty, ale nie jest wywoływany przez analizowaną sekwencję. Nie zakładano jego równoległego działania.

### Kontrola receptury

Ruchy i obliczenia tej sekwencji mają ustawienia dla receptury 30 (trójnik 26,9 mm). `WYBOR_PROGRAMU` zawiera także inne receptury, lecz nie dostarczają one pełnego, odpowiedniego zestawu obliczeń dla tej sekwencji.

Jeśli na początku cyklu `I035` jest inne niż 30, wersja robocza wykonuje `PAUSE` przed ruchem. Po wznowieniu wraca do kontroli receptury. To wstrzymanie programu, a nie funkcja bezpieczeństwa. Potwierdzenie działania `PAUSE` i wznowienia w danej konfiguracji DX200 jest częścią prób na kontrolerze.

## Naliczanie zużycia — zachowane celowo

| Tryb | Wywołania obliczeń na sztukę | Łączna zmiana I075 przy braku resetu |
|---|---:|---|
| Cały trójnik, 4 przejścia na stronę | 3 | `-3 × I072` |
| Cały trójnik, 8 przejść na stronę | 6 | `-6 × I072` |
| Spaw, 15 obiegów | 15 | `-15 × I072` |

Każde wywołanie dodaje też `I072 × 100` do `D074`. `B030=1` dodatkowo inicjalizuje dane ściernicy, po czym jest zerowane, a `OT#(6)` wyłączane. Użytkownik potwierdził, że obecne naliczanie jest celowe. Dlatego drugi zestaw obliczeń przed górnymi przejściami w trybie 8 nie jest zbędnym wywołaniem.

## Czas cyklu i dalsze możliwości

| Tryb, bez wymiany narzędzia i bez oczekiwania na nowy detal | Polecenia ruchu na sztukę | Suma jawnych TIMER | Mniej wykonywanych instrukcji w modelu |
|---|---:|---:|---:|
| Spaw | 99 | 6,4 s | 86 |
| Cały, 4 przejścia | 71 | 6,8 s | 197 |
| Cały, 8 przejść | 107 | 6,8 s | 404 |

Jeśli taśma wymaga podania detalu, dochodzi 0,6 s jawnych timerów i czas oczekiwania `WAIT IN#(16)=ON`. Wymiana narzędzia dodaje ruchy i czas `WAIT IN#(13)=ON`. Impuls `OT#(19)` zależy od licznika `B010`; tabelę wyliczono dla normalnej ścieżki z wysłaniem tego impulsu.

Te wartości **nie są czasem cyklu**: nie zawierają czasu ruchów, przyspieszeń, hamowania ani odpowiedzi urządzeń. Liczba usuniętych instrukcji także nie przekłada się bezpośrednio na sekundy. Brak dostępu do DX200/MotoSim i stanowiska uniemożliwia pomiar rzeczywistego przyspieszenia.

Największe kandydaty do kolejnego etapu:

1. Rozruch i zatrzymanie szlifierki: po 2 s, razem 4 s na sztukę. Po potwierdzeniu stref i sygnałów można rozważyć rozruch równoległy z dojazdem. Oczekiwanie na zatrzymanie może być wymagane przed demontażem — nie wolno usuwać go na podstawie samego kodu.
2. Ruchy transportowe i prędkości z `I022`. Ta sama zmienna trafia do `V=` przy ruchach liniowych i do `VJ=` przy ruchach przegubowych. Te parametry mają różną skalę na kontrolerze. `ODJAZD_OD_TROJNIKA` kończy z `I022=1000`, a demontaż i wymiana narzędzia używają tego zastanego ustawienia. Trzeba odczytać rzeczywistą prędkość na pendantzie i zmierzyć czasy tych etapów, zanim dobierze się osobne prędkości.
3. Czasy ssania, docisku i sygnalizacji: zbadać rzeczywistą odpowiedź oraz dostępne potwierdzenia. Zmniejszać dopiero po pomiarze i sprawdzeniu powtarzalności chwytu.
4. `PL=0` na końcach szlifu i przy mocowaniu: możliwe ograniczenie czasu, ale zmiana wpływa na dokładność, obróbkę i przebieg ruchu. Pozostawiono bez zmian.

## Ustalenia dotyczące niezawodności

| Miejsce | Obserwacja | Dalsze działanie |
|---|---|---|
| Wybór spaw/cały | Kilka odczytów `OT#(33)` mogło ustawić punkty dla innego trybu niż późniejsze ruchy. | W tej wersji tryb pochodzi z jednego odczytu na początku sztuki. |
| Korekty | Były ponownie przeliczane między stronami i obiegami. | W tej wersji obowiązują wartości z początku sztuki. |
| Receptura | Brak kontroli zgodności z trajektorią trójnika. | Dodano kontrolę receptury 30 przed ruchem. |
| Taśma | `WAIT IN#(16)=ON` nie ma limitu. Przy braku sygnału program pozostaje w oczekiwaniu z `OT#(24)=ON`. | Ustalić maksymalny czas podania i reakcję PLC/robota na przekroczenie. W tej wersji nie wprowadzono zgadywanego limitu. |
| Wymiana narzędzia | `WAIT IN#(13)=ON` także nie ma limitu, z `OT#(9)=ON`. | Ustalić protokół i maksymalny czas wymiany. W `IONAME.DAT` wejście 13 nazywa się `RESET_PAS`, a nie potwierdzenie zamknięcia chwytaka. |
| WAIT i kolejne IF | Po zakończeniu oczekiwania sygnał jest sprawdzany jeszcze raz. Jeśli zniknie, wyłączenie wyjścia może zostać pominięte. | Potwierdzić, czy sygnał jest poziomowy czy impulsowy; ustalić potwierdzenie i obsługę przerwania. |
| Ssanie/docisk | W tych podprogramach gotowość opiera się na timerach, bez jawnego oczekiwania na potwierdzenie. | Sprawdzić rzeczywiste zabezpieczenia PLC i dostępne czujniki. Sama nazwa wejścia nie dowodzi jego funkcji. |
| Zużyta ściernica | Kontrola `I075<=I076` jest po obróbce i tylko dla całego trójnika (`B015=0`). Zapis archiwalny ma `I075=177`, `I076=180`. | Sprawdzić aktualny stan i celowość progu; ustalić, czy kontrola jest potrzebna również przed obróbką i dla spawu. Nie zmieniono sekwencji wymiany. |
| Punkty P | Nie tylko pozycje, ale również tool i konfiguracja są stanem globalnym. | Nie usuwać inicjalizacji pozornie nieużywanego `P000` w pobraniu bez analizy dalszych użyć. Ruch do niego jest `COMM`, lecz sam zapis nadal ma skutki. |

Nazwy wybranych wyjść z archiwum: `OT#(6)` RESET GALKI, `OT#(9)` WYMIEN_PAS, `OT#(10)` DOCISK CIETKI, `OT#(19)` GOLEM, `OT#(21)` SSANIE, `OT#(23)` START SZLIFIERKI, `OT#(24)` START_TASMA, `OT#(26)` ILOSC PRZEJSC, `OT#(33)` SZLIF SPAW/CALY. Nazwy nie zastępują dokumentacji elektrycznej ani sprawdzenia PLC.

## Zakres weryfikacji

Wykonano własny model arytmetyki i sterowania dla instrukcji występujących w tych jobach. Porównano oryginał i wersję roboczą w **288 scenariuszach pełnego cyklu** przy stabilnych ustawieniach, dla obu sposobów zaokrąglania modelu: obcięcie i zaokrąglenie do najbliższej liczby. Scenariusze obejmują tryb spawu/4/8 przejść, reset ściernicy, obecność detalu, wymianę narzędzia, różne korekty, wartości zużycia i graniczne wartości `B010`.

Wszystkie scenariusze porównały każdy zapis `SETE`, każde polecenie ruchu wraz z punktem i prędkością, timery, `WAIT`, zmiany wyjść, kolejność wywołań oraz końcowy stan zmiennych. Nie stwierdzono różnic dla stabilnych ustawień i prawidłowej receptury.

Dodatkowo sprawdzono 3 scenariusze zmiany trybów i korekt w trakcie sztuki: obecna sztuka pozostała niezmieniona, a kolejna użyła nowych ustawień. Sprawdzono 7 nieobsługiwanych receptur: model zatrzymał wykonanie przed ruchem i zmianą wyjść. Dla 21 plików potwierdzono identyczne sekcje pozycji, listy ruchów, wyjść, timerów, oczekiwań i wywołań oraz format CRLF.

**Model nie jest kompilatorem INFORM ani symulatorem DX200.** Przy `WAIT` zakłada skuteczną odpowiedź urządzenia; nie odwzorowuje czasu, PLC, awarii, drgań wejść, planowania ruchu, kinematyki ani kolizji. Nie dowodzi poprawności fizycznego stanowiska. Nie modeluje równoległego nadpisywania roboczych zmiennych D/P. Zmiana czasu wykonywania obliczeń wymaga sprawdzenia na docelowym kontrolerze.

## Pliki i użycie

- `JBI_REVIEW/`: komplet 21 jobów do przeglądu, z zachowanymi nazwami. Załadowanie może zastąpić istniejące joby — najpierw zachować aktualną kopię.
- `ORIGINAL_JBI/`: 21 oryginalnych jobów analizowanej sekwencji, bez zmian.
- `changes.diff`: pełne porównanie kodu.
- `change_manifest.json`: sumy SHA-256 i lista 201 usuniętych przypisań z numerami linii oryginału.
- `validation_results.json`: wyniki wykonanych sprawdzeń.
- `tools/validate.py`: odtwarzalny model porównawczy, standardowa biblioteka Python 3. Uruchomienie: `python tools/validate.py` z katalogu paczki.
- `tools/initial_model_state.json`: stan początkowy modelu odczytany z archiwum; nie jest plikiem do załadowania do robota.
- `MAPA_WYWOLAN.md`: zależności i diagram sekwencji.

Przed użyciem na stanowisku: sprawdzić import i polecenia na DX200/MotoSim; potwierdzić bieżące TOOL/UFRAME i stan roboczych zmiennych; sprawdzić sekwencję od pozycji startowej w trybie krokowym z ograniczoną prędkością; zweryfikować oba tryby i zmianę ustawień w trakcie sztuki; zmierzyć jakość obróbki i czasy etapów. Nie wykonywano żadnego przesyłania ani uruchamiania kodu na robocie.

Do dalszego skrócenia czasu potrzebne są czasy etapów lub nagranie cyklu z widocznym przebiegiem, opis potwierdzeń rozruchu/zatrzymania szlifierki i protokół wymiany narzędzia. Zmiany ruchów, PL, czasów procesowych i obsługi awarii można wtedy oprzeć na danych ze stanowiska.
