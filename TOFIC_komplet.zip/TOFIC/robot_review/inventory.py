from pathlib import Path
import re,json
root=Path('/workspace/robot_review/original/TOFIK')
jobs={}
for p in root.glob('*.JBI'):
 raw=p.read_bytes(); txt=raw.decode('cp1250')
 name=re.search(r'^//NAME (.+)',txt,re.M)[1].strip()
 jobs[name]={'path':str(p),'text':txt,'calls':re.findall(r'^[ \t]*CALL JOB:([^\s]+)',txt,re.M)}
seen=set(); queue=['TROJNIK_TEST']
while queue:
 n=queue.pop(0)
 if n in seen:continue
 seen.add(n)
 if n in jobs:queue.extend(jobs[n]['calls'])
 else:print('MISSING:',n)
print('TOTAL JOBS:',len(jobs),'REACHABLE:',len(seen))
for n in sorted(seen):
 j=jobs.get(n,{})
 print(n, len(j.get('text','').splitlines()), '->', ', '.join(j.get('calls',[])))
Path('/workspace/robot_review/graph.json').write_text(json.dumps({n:{k:v for k,v in jobs[n].items() if k!='text'} for n in sorted(seen) if n in jobs},indent=2))
Path('/workspace/robot_review/reachable.txt').write_text(''.join('\n===== '+n+' =====\n'+jobs[n]['text'] for n in sorted(seen) if n in jobs),encoding='utf-8')
