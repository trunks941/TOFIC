from pathlib import Path
import re,json,hashlib,difflib
B=Path('/workspace/robot_review'); R=B/'original/TOFIK'; O=B/'delivery/JBI_REVIEW'
def read(p):return p.read_bytes().decode('cp1250')
def write(p,s):p.write_bytes(s.encode('cp1250'))
# Capture only the signals and corrections the user said should take effect on the next piece.
p=O/'TROJNIK_TEST.JBI';s=read(p)
s=s.replace("'WERSJA DO WERYFIKACJI OFFLINE\r\n'RUCHY I SYGNALY JAK W ORYGINALE\r\n'TRYB: B015 / OT#(33)\r\n'ZUZYCIE: OBLICZENIA MAJA SKUTKI", "'WERSJA DO WERYFIKACJI OFFLINE\r\n'TRYBY I KOREKTY CO SZTUKE\r\n'ZUZYCIE JAK W ORYGINALE")
s=s.replace("'POCZATEK KOLEJNEJ SZTUKI\r\n", """'POCZATEK KOLEJNEJ SZTUKI
'WYMAGANA RECEPTURA TROJNIKA
IFTHENEXP I035=30
	 NOP
ELSE
	'USTAW I035=30 I WZNOW
	 PAUSE
	 JUMP *LOOP
ENDIF
'ZATRZASK TRYBU I KOREKT
DIN B015 OT#(33)
IFTHENEXP B015=1
	 SET D103  EXPRESS I103 * 100
	 SET D104  EXPRESS I104 * 100
	 SET D105  EXPRESS I105 * 100
ELSE
	 DIN B012 OT#(26)
	 SET D100  EXPRESS I100 * 100
	 SET D101  EXPRESS I101 * 100
	 SET D102  EXPRESS I102 * 100
	 SET D103  EXPRESS I103 * 100
	 SET D104  EXPRESS I104 * 100
	 SET D105  EXPRESS I105 * 100
	 SET D106  EXPRESS I106 * 100
	 SET D107  EXPRESS I107 * 100
	 SET D108  EXPRESS I108 * 100
ENDIF
""".replace('\n','\r\n'))
write(p,s)
for n in ['MONTAZ_TROJNIKA','OBLICZENIA_KROKOW_TROJNIKI','WYBOR_SZLIFU']:
 p=O/(n+'.JBI');s=read(p);assert s.count('DIN B015 OT#(33)')==1
 s=s.replace('DIN B015 OT#(33)', "'B015 Z TROJNIK_TEST")
 s=s.replace("'TRYB ODCZYTYWANY PONOWNIE", "'TRYB ZATRZASK Z TROJNIK_TEST")
 write(p,s)
p=O/'SZLIF_TROJNIKA.JBI';s=read(p);assert s.count('DIN B012 OT#(26)')==1
write(p,s.replace('DIN B012 OT#(26)', "'B012 Z TROJNIK_TEST"))
for n in ['OBLICZ_SZLIF_TROJNIKA']+['OBLICZ_SZLIF_CALY_TROJ_'+str(i) for i in range(1,4)]:
 p=O/(n+'.JBI');s=read(p)
 s,count=re.subn(r'^SET D10[0-8]  EXPRESS I10[0-8] \* 100\r\n','',s,flags=re.M);assert count==3
 s=s.replace("'RESET: B030 ORAZ OT#(6)", "'RESET: B030 ORAZ OT#(6)\r\n'D100-D108 Z TROJNIK_TEST")
 write(p,s)
# Complete diff and manifest from source data, including semantics changes.
stats=json.loads((B/'delivery/change_manifest.json').read_text());diff=[]
for n,st in stats.items():
 orig=R/(n+'.JBI');new=O/(n+'.JBI')
 st['review_sha256']=hashlib.sha256(new.read_bytes()).hexdigest()
 diff.extend(difflib.unified_diff(read(orig).splitlines(keepends=True),read(new).splitlines(keepends=True),fromfile='ORIGINAL/'+orig.name,tofile='JBI_REVIEW/'+new.name))
(B/'delivery/changes.diff').write_text(''.join(diff),encoding='utf-8')
(B/'delivery/change_manifest.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
print('Cycle modes/corrections and recipe guard applied.')
