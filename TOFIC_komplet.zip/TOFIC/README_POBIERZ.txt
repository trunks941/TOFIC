TOFIC — komplet plików do przeniesienia na komputer

Rozpakuj ZIP do wybranego katalogu na komputerze.
Repozytorium Git w chmurze nie zawiera jeszcze commitów.
W tym eksporcie umieszczono także wszystkie pliki pracy nad kodem robota.

robot_review/delivery/JBI_REVIEW — przygotowane programy JBI do weryfikacji
robot_review/delivery/ORIGINAL_JBI — oryginały analizowanych programów
robot_review/delivery/RAPORT_PL.md — raport zmian i ograniczeń
robot_review/original/TOFIK — pełny oryginalny zrzut (156 plików)
attachments/TOFIK_270826.rar — przesłane archiwum

Archiwum zawiera metadane Git; konfiguracja origin wskazuje zwykły adres
GitHub. Konfiguracja uwierzytelniania środowiska chmurowego nie jest eksportowana.

Weryfikacja offline (Python 3):
  cd robot_review/delivery
  python tools/validate.py

Pliki JBI są wersją do sprawdzenia na DX200/MotoSim przed wdrożeniem.
