"""Offline differential model of the subset used in these jobs. Not a DX200 simulator."""
from pathlib import Path
from fractions import Fraction
import ast,re,json,random,copy,hashlib
BASE=Path('/workspace/robot_review'); SRC=BASE/'original/TOFIK'; NEW=BASE/'delivery/JBI_REVIEW'
GRAPH=json.loads((BASE/'graph.json').read_text())
def text(p):return p.read_bytes().decode('cp1250')
def code(p):
 s=text(p);return [l.strip() for l in s[s.index('//INST'):].splitlines() if l.strip() and not l.strip().startswith(('//',"'",'COMM '))]
def parse(lines):
 def seq(i,stops=()):
  out=[]
  while i<len(lines):
   s=lines[i];word=s.split()[0]
   if word in stops:return out,i
   if word=='IFTHENEXP':
    yes,j=seq(i+1,('ELSE','ENDIF'));no=[]
    if lines[j]=='ELSE':no,j=seq(j+1,('ENDIF',))
    assert lines[j]=='ENDIF';out.append(('if',s[len(word):].strip(),yes,no));i=j+1
   elif word=='FOR':
    m=re.fullmatch(r'FOR (I\d{3}) START=\s*(-?\d+) TO (-?\d+) STEP=\s*(-?\d+)',s);assert m,s
    body,j=seq(i+1,('NEXT',));assert lines[j]=='NEXT '+m[1]
    out.append(('for',m[1],int(m[2]),int(m[3]),int(m[4]),body));i=j+1
   elif word=='SWITCH':
    cases=[];j=i+1
    while lines[j]!='ENDSWITCH':
     assert lines[j].startswith('CASE '),lines[j];v=int(lines[j].split()[1]);body,j=seq(j+1,('CASE','ENDSWITCH'));cases.append((v,body))
    out.append(('switch',s.split()[1],cases));i=j+1
   else:out.append(('line',s));i+=1
  return out,i
 n,end=seq(0);assert end==len(lines);return n
class Model:
 def __init__(self,root,values,inputs,outputs,rounding='trunc',hook=None):
  self.root=root;self.v=copy.deepcopy(values);self.ins=dict(inputs);self.ots=dict(outputs);self.trace=[];self.calls=[];self.count=0;self.rounding=rounding;self.hook=hook;self.paused=False
  self.programs={n:parse(code(root/(n+'.JBI'))) for n in GRAPH}
  self.cp={}
  for n in GRAPH:
   tool=None; points={}
   for l in text(root/(n+'.JBI')).split('//INST')[0].splitlines():
    if l.startswith('///TOOL '):tool=int(l.split()[1])
    if re.match(r'C\d{5}=',l):points[l.split('=')[0]]=(l.split('=')[1],tool)
   self.cp[n]=points
 def get(self,k):return self.v.get(k,0)
 def number(self,node):
  if isinstance(node,ast.Expression):return self.number(node.body)
  if isinstance(node,ast.Constant):return Fraction(str(node.value))
  if isinstance(node,ast.Name):return Fraction(self.get(node.id))
  if isinstance(node,ast.UnaryOp):
   v=self.number(node.operand);return -v if isinstance(node.op,ast.USub) else v
  if isinstance(node,ast.BinOp):
   a,b=self.number(node.left),self.number(node.right)
   if isinstance(node.op,ast.Add):return a+b
   if isinstance(node.op,ast.Sub):return a-b
   if isinstance(node.op,ast.Mult):return a*b
   if isinstance(node.op,ast.Div):return a/b
  raise ValueError(ast.dump(node))
 def expr(self,s):return self.number(ast.parse(s.strip().removeprefix('EXPRESS').strip(),mode='eval'))
 def set(self,k,v):
  v=int(v) if self.rounding=='trunc' else round(v)
  if k.startswith('B'):v%=256
  if k.startswith('I'):v=(v+32768)%65536-32768
  if k.startswith('D'):v=(v+2147483648)%4294967296-2147483648
  self.v[k]=v
 def cond(self,s):
  m=re.fullmatch(r'(.*?)(<=|>=|<>|=|<|>)(.*)',s);assert m,s
  def term(t):
   t=t.strip();a=re.fullmatch(r'(IN|OT)#\((\d+)\)',t)
   if a:return (self.ins if a[1]=='IN' else self.ots).get(int(a[2]),0)
   return {'ON':1,'OFF':0}.get(t,self.expr(t) if t not in ['ON','OFF'] else 0)
  a,b=term(m[1]),term(m[3]);return {'=':a==b,'<>':a!=b,'<':a<b,'>':a>b,'<=':a<=b,'>=':a>=b}[m[2]]
 def run(self,n,uf=None):
  self.calls.append(n)
  if self.hook:self.hook(self,n,'enter')
  ret=self.block(self.programs[n],n,uf)
  if self.hook:self.hook(self,n,'leave')
  return ret
 def block(self,nodes,n,uf):
  for node in nodes:
   self.count+=1;kind=node[0]
   if kind=='if':
    r=self.block(node[2] if self.cond(node[1]) else node[3],n,uf)
    if r:return r
   elif kind=='for':
    _,v,start,end,step,body=node;self.set(v,start)
    while (self.get(v)<=end if step>0 else self.get(v)>=end):
     r=self.block(body,n,uf)
     if r:return r
     self.set(v,self.get(v)+step)
   elif kind=='switch':
    for value,body in node[2]:
     if self.get(node[1])==value:
      r=self.block(body,n,uf)
      if r:return r
      break
   else:
    s=node[1];op=s.split()[0]
    if op in ['NOP'] or s.startswith('*'):continue
    if op in ['RET','END']:return 'return'
    if op=='JUMP':return 'cycle_complete'
    if op=='PAUSE':self.paused=True;self.trace.append(('PAUSE',n));return 'paused'
    if op=='SET':
     m=re.fullmatch(r'SET ([BID]\d{3})\s+(.*)',s);assert m,s;self.set(m[1],self.expr(m[2]))
    elif op in ['ADD','MUL']:
     _,v,arg=s.split();x=self.expr(arg);self.set(v,self.get(v)+x if op=='ADD' else self.get(v)*x)
    elif op=='SETE':
     m=re.fullmatch(r'SETE (P\d{3}|P\[I\d{3}\]) (?:\((\d+)\) (D\d{3})|TL#\((\d+)\))',s);assert m,s
     v=m[1]
     if '[' in v:v='P'+str(self.get(v[2:-1])).zfill(3)
     elem=int(m[2]) if m[2] else 'tool';value=self.get(m[3]) if m[3] else int(m[4])
     self.v.setdefault(v,{})[elem]=value;self.trace.append(('SETE',n,v,elem,value))
    elif op=='DIN':
     m=re.fullmatch(r'DIN (B\d{3}) OT#\((\d+)\)',s);assert m,s;self.set(m[1],self.ots.get(int(m[2]),0))
    elif op=='DOUT':
     m=re.fullmatch(r'DOUT OT#\((\d+)\) (ON|OFF)',s);assert m,s;v=int(m[2]=='ON');self.ots[int(m[1])]=v;self.trace.append(('DOUT',n,int(m[1]),v))
    elif op=='TIMER':self.trace.append(('TIMER',n,s))
    elif op=='WAIT':
     self.trace.append(('WAIT',n,s))
     # Successful handshake path: assert sensor after waiting, no timing/PLC simulation.
     m=re.fullmatch(r'WAIT IN#\((\d+)\)=(ON|OFF)',s);assert m,s;self.ins[int(m[1])]=int(m[2]=='ON')
    elif op=='CALL':
     m=re.fullmatch(r'CALL JOB:(\S+)(?: UF#\((\d+)\))?',s);assert m,s
     r=self.run(m[1],int(m[2]) if m[2] else uf)
     if r=='paused':return r
    elif op in ['MOVJ','MOVL','MOVC']:
     m=re.fullmatch(r'(MOV[JLC]) (C\d{5}|P\d{3}) (VJ|V)=([I\d.]+) PL=(\d+)',s);assert m,s
     p=self.cp[n][m[2]] if m[2].startswith('C') else copy.deepcopy(self.v.get(m[2],{}))
     speed=self.get(m[4]) if m[4].startswith('I') else m[4]
     self.trace.append(('MOVE',n,uf,m[1],m[2],p,m[3],speed,m[5]))
    else:raise ValueError((n,s))
  return None

def initial():
 s=text(SRC/'VAR.DAT');v={}
 for typ in ['B','I','D']:
  data=s.split('///'+typ+'\r\n')[1].split('///')[0];a=[int(x) for x in data.replace('\r\n',',').split(',') if x.strip()]
  v.update({typ+str(i).zfill(3):x for i,x in enumerate(a)})
 data=s.split('///P\r\n')[1]
 for i,l in enumerate(data.splitlines()):
  if not l.startswith('"RECTAN"'):break
  a=l.replace('"RECTAN"','').split(',');v['P'+str(i).zfill(3)]={'tool':int(a[2]),'metadata':a[:6]}
  for e,x in enumerate(a[6:12],1):v['P'+str(i).zfill(3)][e]=int(Fraction(x)*(1000 if e<=3 else 10000))
 return v

def structural():
 for n in GRAPH:
  a=SRC/(n+'.JBI');b=NEW/a.name;s=text(a);t=text(b)
  assert s.split('//INST')[0]==t.split('//INST')[0],n
  assert b.read_bytes().count(b'\n')==b.read_bytes().count(b'\r\n'),n
  assert re.findall(r'^[ \t]*CALL JOB:.*',s,re.M)==re.findall(r'^[ \t]*CALL JOB:.*',t,re.M),n
  assert [l for l in code(a) if l.startswith(('MOV','DOUT','TIMER','WAIT','FOR ','NEXT '))]==[l for l in code(b) if l.startswith(('MOV','DOUT','TIMER','WAIT','FOR ','NEXT '))],n
  parse(code(a));parse(code(b))
 return len(GRAPH)

def main():
 structural_count=structural();rng=random.Random(20261014);cases=0;maxsaved=0;savings={};cycles=[]
 for rounding in ['trunc','nearest']:
  for mode,passes in [(1,0),(0,0),(0,1)]:
   for reset in [0,1]:
    for conveyor in [0,1]:
     for replacement in [0,1]:
      for sample in range(6):
       v=initial();v['I035']=30;v['I070']=rng.randint(100,240);v['I072']=rng.randint(0,3);v['I075']=130 if replacement else 240;v['I076']=180;v['I074']=rng.randint(10,25);v['B010']=rng.choice([0,1,254,255]);v['D074']=rng.randint(-500,10000)
       for i in range(100,109):v['I'+str(i)]=rng.randint(-150,150)
       ins={16:conveyor,13:0};ots={33:mode,26:passes,6:reset,5:rng.choice([0,1])}
       a=Model(SRC,v,ins,ots,rounding);b=Model(NEW,v,ins,ots,rounding)
       a.run('TROJNIK_TEST');b.run('TROJNIK_TEST')
       assert a.trace==b.trace,(mode,passes,reset,conveyor,replacement,sample,'trace')
       assert a.v==b.v,(mode,passes,reset,conveyor,replacement,sample,'vars')
       assert a.ots==b.ots and a.ins==b.ins
       assert a.calls==b.calls
       cases+=1;saved=a.count-b.count;savings.setdefault(f'{mode}/{passes}',set()).add(saved);maxsaved=max(maxsaved,saved)
       if reset==0 and conveyor==1 and replacement==0 and sample==0 and rounding=='trunc':
        cycles.append({'mode_spaw':mode,'mode_8_przejsc':passes,'calculation_calls':len([n for n in a.calls if n.startswith('OBLICZ_SZLIF_')]),'moves':len([e for e in a.trace if e[0]=='MOVE']),'fixed_timer_seconds':sum(float(e[2].split('=')[1]) for e in a.trace if e[0]=='TIMER'),'model_statements_original':a.count,'model_statements_review':b.count})
 # Midcycle settings changes must not affect current piece; they are applied next cycle.
 latching=[]
 for mode,passes in [(1,0),(0,0),(0,1)]:
  v=initial();v['I075']=250;v['I076']=180;v['I072']=0;ins={16:1,13:1};ots={33:mode,26:passes,6:0,5:0}
  baseline=Model(NEW,v,ins,ots);baseline.run('TROJNIK_TEST')
  changed=False
  def hook(m,n,stage):
   nonlocal changed
   if n=='START_TASMA_TROJNIK' and stage=='leave' and not changed:
    changed=True;m.ots[33]=1-mode;m.ots[26]=1-passes
    for i in range(100,109):m.v['I'+str(i)]+=100
  live=Model(NEW,v,ins,ots,hook=hook);live.run('TROJNIK_TEST')
  assert baseline.trace==live.trace and baseline.calls==live.calls
  assert baseline.v['B015']==live.v['B015']==mode
  live.hook=None;live.trace=[];live.calls=[];live.run('TROJNIK_TEST')
  assert live.v['B015']==1-mode
  if 1-mode==0:assert live.v['B012']==1-passes
  # Next cycle captures updated corrections, for the active side/branch.
  corr=range(103,106) if 1-mode==1 else range(100,109)
  for i in corr:assert live.v['D'+str(i)]==live.v['I'+str(i)]*100
  latching.append({'initial_mode':mode,'initial_passes':passes,'current_cycle_unchanged':True,'next_cycle_updated':True})
 guards=0
 for recipe in [-1,0,20,22,28,31,32767]:
  v=initial();v['I035']=recipe;m=Model(NEW,v,{16:1},{33:0,26:0});m.run('TROJNIK_TEST')
  assert m.paused and not any(e[0] in ['MOVE','DOUT'] for e in m.trace);guards+=1
 report={'model_note':'Offline arithmetic/control-flow differential model; not controller, PLC, timing or kinematics validation. Successful WAIT handshakes assumed. No concurrent writes to D/P working data modeled. Integer casts modeled with truncation and nearest rounding. Final state and each SETE/MOVE/DOUT/TIMER/WAIT compared.', 'structural_job_checks':structural_count,'differential_cycle_cases_passed':cases,'rounding_models':['trunc','nearest'],'setting_latch_scenarios':latching,'invalid_recipe_guard_cases_passed':guards,'model_statement_savings':{k:sorted(v) for k,v in savings.items()},'representative_cycles':cycles}
 (BASE/'delivery/validation_results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
