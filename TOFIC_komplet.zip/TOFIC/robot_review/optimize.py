from pathlib import Path
import json,re,hashlib,difflib
BASE=Path('/workspace/robot_review'); ORIG=BASE/'original/TOFIK'; OUT=BASE/'delivery/JBI_REVIEW'
OUT.mkdir(parents=True,exist_ok=True)
graph=json.loads((BASE/'graph.json').read_text())
stats={}; diffs=[]
notes={
'TROJNIK_TEST': ['WERSJA DO WERYFIKACJI OFFLINE','RUCHY I SYGNALY JAK W ORYGINALE','TRYB: B015 / OT#(33)','ZU ZYCIE: OBLICZENIA MAJA SKUTKI'],
'SZLIF_TROJNIKA':['B012=0: 4 PRZEJSCIA NA STRONE','B012=1: 8 PRZEJSC NA STRONE','NIE USUWAC POWTORNYCH OBLICZEN','KAZDE WY WOLANIE NALICZA I072'],
'SZLIF_SPAWU_TROJNIKA':['15 OBIEGOW: ZU ZYCIE CO OBIEG','P010-P013: GLOBALNE PUNKTY'],
'WYBOR_SZLIFU':['OT#(33): 1=SPAW, 0=CALY','TRYB ODCZYTYWANY PONOWNIE'],
'OBLICZENIA_KROKOW_TROJNIKI':['P000-P008: GLOBALNE PUNKTY','P009: TAKZE ZMIANA TOOL W PETLI'],
'OBLICZ_SZLIF_TROJNIKA':['OBLICZENIA ZMIENIAJA ZU ZYCIE','I075-=I072, D074+=I072*100','RESET: B030 ORAZ OT#(6)'],
'START_TASMA_TROJNIK':['IN#(16): POZYCJA CIETKI','WAIT BEZ LIMITU JAK W ORYGINALE'],
'ODLOZ_TROJNIK':['IN#(13): RESET_PAS WG IONAME','WAIT BEZ LIMITU JAK W ORYGINALE','I022: ZOSTAJE Z ODJAZDU'],
'MONTAZ_TROJNIKA':['OT#(10): DOCISK CIETKI','OT#(21): SSANIE'],
'DEMONTAZ_TROJNIKA':['I022: UZYTE TAKZE JAKO VJ','OT#(21): SSANIE'],
'POBRANIE_Z_TASMY_TROJNIK':['RUCH P000 JEST COMM W ORYGINALE','ZAPIS P000 ZOSTAWIONY CELOWO']}
for i in range(1,4):notes['OBLICZ_SZLIF_CALY_TROJ_'+str(i)]=notes['OBLICZ_SZLIF_TROJNIKA']+['STALA ORIENTACJA LICZONA RAZ']
stages={
'CALL JOB:WYBOR_PROGRAMU':'01 PARAMETRY DETALU',
'CALL JOB:START_TASMA_TROJNIK':'02 OCZEKIWANIE NA DETAL',
'CALL JOB:DOJAZD_DO_TASMY UF#(10)':'03 DOJAZD DO TASMY',
'CALL JOB:POBRANIE_Z_TASMY_TROJNIK UF#(15)':'04 POBRANIE DETALU',
'CALL JOB:MONTAZ_TROJNIKA':'05 ZAMOCOWANIE',
'CALL JOB:WYBOR_SZLIFU':'06 OBROBKA SPAWU LUB 3 STRON',
'CALL JOB:ODJAZD_OD_TROJNIKA UF#(18)':'07 ODJAZD I STOP SZLIFIERKI',
'CALL JOB:DEMONTAZ_TROJNIKA':'08 DEMONTAZ',
'CALL JOB:ODLOZ_TROJNIK':'09 ODLOZENIE I WYMIANA PASA'}
for n in graph:
 p=ORIG/(n+'.JBI'); raw=p.read_bytes();s=raw.decode('cp1250');lines=s.splitlines()
 optimized=[]; removed=[]; cache={}; versions={}; tail=False
 for line_no,l in enumerate(lines,1):
  t=l.strip()
  if n.startswith('OBLICZ_SZLIF_CALY_TROJ_') and t=="'OBLICZENIA PUNKTOW'":tail=True
  if n=='OBLICZ_SZLIF_TROJNIKA' and t=='ENDSWITCH':tail=True
  m=re.fullmatch(r'SET (D\d{3})\s+(.*)',t)
  if tail and m:
   target,rhs=m.groups();refs=re.findall(r'\b([BIDRP]\d{3})\b',rhs)
   sig=(rhs,tuple((v,versions.get(v,0)) for v in refs))
   if all(v.startswith('D') for v in refs) and cache.get(target)==sig:
    removed.append({'original_line':line_no,'instruction':t});continue
   cache[target]=sig;versions[target]=versions.get(target,0)+1
  optimized.append(l)
  if t=='NOP' and n in notes:
   optimized.extend("'"+v.replace('ZU ZYCIE','ZUZYCIE').replace('WY WOLANIE','WYWOLANIE') for v in notes[n])
  if n=='TROJNIK_TEST' and t=='*LOOP':optimized.append("'POCZATEK KOLEJNEJ SZTUKI")
  if n=='TROJNIK_TEST' and t in stages:
   optimized.insert(len(optimized)-1,"'"+stages[t])
 new=('\r\n'.join(optimized)+'\r\n').encode('cp1250')
 (OUT/p.name).write_bytes(new)
 stats[n]={'removed_sets':len(removed),'removed':removed,'original_sha256':hashlib.sha256(raw).hexdigest(),'review_sha256':hashlib.sha256(new).hexdigest()}
 diffs.extend(difflib.unified_diff(s.splitlines(keepends=True),new.decode('cp1250').splitlines(keepends=True),fromfile='ORIGINAL/'+p.name,tofile='JBI_REVIEW/'+p.name))
 print(n, 'removed SET:',len(removed))
(BASE/'delivery/changes.diff').write_text(''.join(diffs),encoding='utf-8')
(BASE/'delivery/change_manifest.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
