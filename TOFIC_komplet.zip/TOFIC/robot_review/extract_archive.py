import ctypes as c, ctypes.util, pathlib, sys
lib=c.CDLL(ctypes.util.find_library('archive'))
def fn(n,rest,args):
 f=getattr(lib,n); f.restype=rest; f.argtypes=args; return f
new=fn('archive_read_new',c.c_void_p,[])
fn('archive_read_support_filter_all',c.c_int,[c.c_void_p])
fn('archive_read_support_format_all',c.c_int,[c.c_void_p])
openfile=fn('archive_read_open_filename',c.c_int,[c.c_void_p,c.c_char_p,c.c_size_t])
nextheader=fn('archive_read_next_header',c.c_int,[c.c_void_p,c.POINTER(c.c_void_p)])
name=fn('archive_entry_pathname',c.c_char_p,[c.c_void_p])
typeof=fn('archive_entry_filetype',c.c_uint,[c.c_void_p])
read=fn('archive_read_data',c.c_ssize_t,[c.c_void_p,c.c_void_p,c.c_size_t])
err=fn('archive_error_string',c.c_char_p,[c.c_void_p])
free=fn('archive_read_free',c.c_int,[c.c_void_p])
a=new(); lib.archive_read_support_filter_all(a);lib.archive_read_support_format_all(a)
if openfile(a,sys.argv[1].encode(),10240)!=0: raise RuntimeError(err(a))
root=pathlib.Path(sys.argv[2]).resolve();root.mkdir(parents=True,exist_ok=True)
n=0
while True:
 e=c.c_void_p();r=nextheader(a,c.byref(e))
 if r==1:break
 if r<0:raise RuntimeError(err(a))
 p=(root/name(e).decode('utf-8').replace('\\','/')).resolve()
 if not p.is_relative_to(root):raise RuntimeError('Unsafe archive path')
 t=typeof(e)
 if t==0o040000:p.mkdir(parents=True,exist_ok=True);continue
 if t!=0o100000:raise RuntimeError('Unsupported nonregular archive member')
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as out:
  buf=c.create_string_buffer(65536)
  while True:
   k=read(a,buf,len(buf))
   if k==0:break
   if k<0:raise RuntimeError(err(a))
   out.write(buf.raw[:k])
 n+=1
free(a);print('Extracted files:',n)
